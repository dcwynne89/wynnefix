# WynneFix 🔧

An AI-powered repair assistant built with OpenAI and deployed on Netlify.

## Features
- Secure serverless backend (your OpenAI key is protected)
- Clean, mobile-friendly interface
- Returns step-by-step fix instructions

## Setup
1. Add your OpenAI API key to Netlify environment variables:
   `OPENAI_API_KEY = sk-xxxxxx`

2. Deploy via Netlify or use `netlify dev` for local development.

Enjoy!
